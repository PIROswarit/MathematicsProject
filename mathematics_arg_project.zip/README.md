# The Mathematical Enigma — Mathematics ARG

An eight-stage, dark terminal-inspired educational puzzle website about applications of mathematics in real life and video games.

## Contents
- `index.html` — Stage 1 home page and project overview
- `stage-02/` through `stage-08/` — separate URL paths, one puzzle per stage
- `style.css` — shared responsive visual theme
- `script.js` — answer checking and hint interaction

## Preview locally
Open `index.html` in a browser. To test all links and relative paths exactly as hosted, run a local static server from this folder, for example:
`python -m http.server 8000`
Then open `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a GitHub repository, e.g. `mathematics-enigma`.
2. Upload the contents of this folder to the repository root (make sure the root `index.html`, `style.css`, and `script.js` are present).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish. Your home URL will be shown in Settings → Pages.
6. Stage paths will look like `https://YOUR-USERNAME.github.io/mathematics-enigma/stage-02/` through `/stage-08/`.

## Important technical note
This is a static educational ARG. Answers are checked in browser JavaScript, so a determined visitor can inspect the source and discover the accepted answers. This is appropriate for a classroom puzzle, but it is not secure encryption or access control. Do not place private data in the pages.

## Puzzle answer key (organiser only)
1. ELECTRIC — reverse Caesar shift of 3
2. GRID — binary ASCII
3. 42 — increasing even differences
4. VECTOR — concept question about magnitude and direction
5. 3/5 — probability
6. SERENITY — reverse Caesar shift of 5
7. LAYER — reverse then shift backwards by 1
8. MATHEMATICS CONNECTS — final revelation

## Vocabulary included
artisanal, paramount, mitigated, poignant, impersonate, personifies, serenity.
